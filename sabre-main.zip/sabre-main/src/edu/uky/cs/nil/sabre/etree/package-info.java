/**
 * Data structures for efficiently determining which events have preconditions
 * which are satisfied in a given state.
 */
package edu.uky.cs.nil.sabre.etree;