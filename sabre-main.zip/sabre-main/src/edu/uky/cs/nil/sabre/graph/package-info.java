/**
 * Data structures for representing the state-space of a planning problem as a
 * finite graph of state nodes linked by temporal and epistemic edges.
 */
package edu.uky.cs.nil.sabre.graph;