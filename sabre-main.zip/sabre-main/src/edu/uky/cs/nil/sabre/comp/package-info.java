/**
 * Tools for compiling planning problems into a representation that enables
 * more efficient knowledge representation and planning.
 */
package edu.uky.cs.nil.sabre.comp;